# Landing Page Project

Project of a simple interactive and responsive landing-page 
